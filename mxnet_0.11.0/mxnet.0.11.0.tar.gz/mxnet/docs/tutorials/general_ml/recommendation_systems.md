# Recommendation Systems

Get the source code for an example of a recommendation system based on MXNet on [GitHub](https://github.com/dmlc/mxnet-notebooks/tree/master/python/recommendation_systems).

## Next Steps
* [MXNet tutorials index](http://mxnet.io/tutorials/index.html)