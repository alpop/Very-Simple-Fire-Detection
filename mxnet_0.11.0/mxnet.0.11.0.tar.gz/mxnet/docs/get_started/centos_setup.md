<!-- This page should be deleted after sometime (Allowing search engines
to update links) -->
<meta http-equiv="refresh" content="3; url=http://mxnet.io/get_started/install.html" />
<!-- Just in case redirection does not work -->
<p>
  <a href="http://mxnet.io/get_started/install.html">
    This content is moved to a new MXNet install page. Redirecting... </a>
</p>
