
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="0; url=http://mxnet.io/get_started/why_mxnet.html">
        <title>Page Redirection</title>
    </head>
</html>
